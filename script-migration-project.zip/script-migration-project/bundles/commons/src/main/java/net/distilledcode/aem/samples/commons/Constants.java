package net.distilledcode.aem.samples.commons;

public class Constants {
    public static final String FOO = "foo";

    public static final String BAR = "bar";
}
